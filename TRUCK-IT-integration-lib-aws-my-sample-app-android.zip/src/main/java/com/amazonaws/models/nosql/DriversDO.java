package com.amazonaws.models.nosql;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.util.List;
import java.util.Map;
import java.util.Set;

@DynamoDBTable(tableName = "truckit-mobilehub-1720687585-Drivers")

public class DriversDO {
    private String _userId;
    private String _address;
    private Double _dL;
    private String _insuranceCo;
    private String _insurancePol;
    private String _name;
    private String _password;
    private String _truckType;
    private String _email;

    @DynamoDBHashKey(attributeName = "userId")
    @DynamoDBAttribute(attributeName = "userId")
    public String getUserId() {
        return _userId;
    }

    public void setUserId(final String _userId) {
        this._userId = _userId;
    }
    @DynamoDBAttribute(attributeName = "Address")
    public String getAddress() {
        return _address;
    }

    public void setAddress(final String _address) {
        this._address = _address;
    }
    @DynamoDBAttribute(attributeName = "DL#")
    public Double getDL() {
        return _dL;
    }

    public void setDL(final Double _dL) {
        this._dL = _dL;
    }
    @DynamoDBAttribute(attributeName = "InsuranceCo")
    public String getInsuranceCo() {
        return _insuranceCo;
    }

    public void setInsuranceCo(final String _insuranceCo) {
        this._insuranceCo = _insuranceCo;
    }
    @DynamoDBAttribute(attributeName = "InsurancePol")
    public String getInsurancePol() {
        return _insurancePol;
    }

    public void setInsurancePol(final String _insurancePol) {
        this._insurancePol = _insurancePol;
    }
    @DynamoDBAttribute(attributeName = "Name")
    public String getName() {
        return _name;
    }

    public void setName(final String _name) {
        this._name = _name;
    }
    @DynamoDBAttribute(attributeName = "Password")
    public String getPassword() {
        return _password;
    }

    public void setPassword(final String _password) {
        this._password = _password;
    }
    @DynamoDBAttribute(attributeName = "TruckType")
    public String getTruckType() {
        return _truckType;
    }

    public void setTruckType(final String _truckType) {
        this._truckType = _truckType;
    }
    @DynamoDBAttribute(attributeName = "email")
    public String getEmail() {
        return _email;
    }

    public void setEmail(final String _email) {
        this._email = _email;
    }

}
